<script>
export default {
  name: "footer-index"
}
</script>

<template>
  <div class="footer-div">
    <h3>footer</h3>
  </div>

</template>

<style scoped>
.footer-div h3{
  text-align: center;

}


</style>