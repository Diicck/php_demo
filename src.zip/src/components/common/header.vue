<script>
export default {
  name: "common-header"
}
</script>

<template>
  <div class="header">
    <img src="@/assets/logo.png" alt="logo" class="logo">
  </div>
</template>

<style scoped>
.header{
  height: 80px;
}
.logo{
  width: auto;
}

</style>