<script>
export default {
  name: "member-data-index"
}
</script>

<template>
  <div>
    <h1>成员数据</h1>
  </div>
</template>

<style scoped>

</style>