<template>
    <HomePage/>
</template>
<script>
import home from "@/Home.vue"
export default {
  name: 'App',
  components:{
    HomePage: home
  }
};
</script>
<style>

</style>